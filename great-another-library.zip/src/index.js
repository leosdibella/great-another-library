import { App } from './app';

new App();